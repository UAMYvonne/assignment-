/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.assignment2;

/**
 *
 * @author educa
 */
import java.util.Scanner;
public class question3{

    public static void main(String[] args) {
       int year;
        System.out.println("Enter  year");
         Scanner n =new Scanner(System.in);
        year=n.nextInt();
if ((year % 4 == 0) && (year % 100 !=0) || (year % 400 == 0)) {
System.out.println("It is leap year");
}
else {

 System.out.println("It is not leap year");       
        
    
}
}
}
